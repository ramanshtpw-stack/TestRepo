# -*- coding: utf-8 -*-
import os
import sys
import csv
import json
import xml.etree.ElementTree as ET

# -------- ENV VARIABLES ----------
PROJECT_PATH = os.environ.get("PROJECT_PATH")
OUTPUT_DIR = os.environ.get("OUTPUT_DIR", r"C:\Users\Public\Exported_Alarms")

PLCOPEN_NAMESPACE = {"plcopen": "http://www.plcopen.org/xml/tc6_0200"}

# NO FALLBACK - Credentials must come from ENV (injected by codesys.py)
USERNAME = os.environ.get("CODESYS_USERNAME", "")
PASSWORD = os.environ.get("CODESYS_PASSWORD", "")

def log(msg):
    try:
        print(msg)
    except:
        print (msg)

log("---- Alarm Export Script Started ----")
log("PROJECT_PATH = " + str(PROJECT_PATH))
log("OUTPUT_DIR  = " + str(OUTPUT_DIR))

if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# ---------------- OPEN PROJECT ----------------
if projects.primary:
    proj = projects.primary
    log("Project already open from CLI.")
else:
    log("Opening project from env...")
    proj = projects.open(PROJECT_PATH)
    if proj is None:
        raise SystemExit("ERROR: Cannot open project.")
    log("Project opened successfully")

# ---------------- LOGIN ----------------
try:
    proj.login(USERNAME, PASSWORD)
    log("Login OK")
except Exception as e:
    log("Login skipped: " + str(e))

# ---------------- EXPORT XML ----------------
xml_raw = proj.export_xml(
    proj.get_children(True),
    recursive=True,
    export_folder_structure=True,
    declarations_as_plaintext=False
)

xml_text = xml_raw[1:]
xml_text = xml_text.encode('ascii', 'ignore').decode('ascii')
if xml_text.startswith("<?xml"):
    xml_text = xml_text.split("?>", 1)[1]

xml_text = "<Root>" + xml_text + "</Root>"
root = ET.fromstring(xml_text)

# ---------------- EXTRACT VARIABLES ----------------
tag_rows = []

for pou in root.findall(".//plcopen:pou", PLCOPEN_NAMESPACE):
    if pou.attrib.get("pouType") != "program":
        continue

    pou_name = pou.attrib.get("name")

    for var in pou.findall(".//plcopen:variable", PLCOPEN_NAMESPACE):
        derived = var.find("plcopen:type/plcopen:derived", PLCOPEN_NAMESPACE)
        if derived is not None:
            tag_rows.append([pou_name, var.attrib["name"], derived.attrib["name"]])

# ---------------- CREATE CSV ----------------
proj_name = os.path.splitext(os.path.basename(PROJECT_PATH))[0]
output_file = os.path.join(OUTPUT_DIR, proj_name + "_alarms.csv")

csv_headers = [
    "ID", "ObservationType", "Details1", "Details2", "Details3",
    "Details4", "Details5", "Details6", "Deactivation", "Class",
    "Message", "OnDelayTime", "OffDelayTime", "Latch1", "Latch2",
    "HigherPrioAlarm"
]

# ---------------- LOAD ALARM JSON ----------------
try:
    json_path = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "alarm_config.json")
    if os.path.exists(json_path):
        f = open(json_path, "r")
        ALARM_CONFIG = json.load(f)
        f.close()
        log("Loaded alarm_config.json")
    else:
        ALARM_CONFIG = {}
        log("Warning: alarm_config.json not found")
except Exception as e:
    ALARM_CONFIG = {}
    log("Error loading JSON: " + str(e))

def read_type_params(derived_type):
    # Lookup derived_type in the loaded JSON object
    if derived_type in ALARM_CONFIG:
        return ALARM_CONFIG[derived_type]
    
    log("Warning: No config found for type: " + derived_type)
    return []

base_dir = os.path.dirname(os.path.abspath(sys.argv[0]))

fh = open(output_file, "w")
writer = csv.writer(fh, delimiter=";", quoting=csv.QUOTE_MINIMAL)

writer.writerow(["#Version: 2.0.0.0"])
writer.writerow(csv_headers)

alarm_id = 1

for pou, tag, dtype in tag_rows:
    params = read_type_params(dtype)

    for p in params:
        param = p.get("Parameter", "").strip()
        value = p.get("Value", "").strip()
        cls = p.get("Class", "").strip()
        obs = p.get("observation_type", "").strip()

        details1 = "Application.%s.%s.%s" % (pou, tag, param)

        if "ioTrip" in param:
            details2 = "FALSE"
        else:
            details2 = "TRUE"

        message = "%s: %s" % (tag, value)

        row = [
            alarm_id, obs, details1, "=", details2,
            "", "", "", "", cls, message,
            "", "", "", "", ""
        ]

        writer.writerow(row)
        alarm_id += 1

fh.close()
log("CSV Export Completed: " + output_file)
log("---- Script Completed ----")


# ---- WRITE SUCCESS FLAG ----
try:
    flag_path = os.path.join(OUTPUT_DIR, "export_done.flag")
    f = open(flag_path, "w")
    f.write("SUCCESS")
    f.close()
    log("Flag created.")
except Exception as e:
    log("Failed writing flag: " + str(e))


# ---- WRITE ALARM COUNT JSON/TXT ----
# ---- WRITE ALARM COUNT JSON/TXT ----
try:
    alarm_count = alarm_id - 1

    count_path = os.path.join(OUTPUT_DIR, "alarm_count.json")
    jf = open(count_path, "w")
    jf.write('{"count": ' + str(alarm_count) + '}')
    jf.close()

    log("Alarm count saved: " + str(alarm_count))

except Exception as e:
    log("Failed writing alarm_count.json: " + str(e))


