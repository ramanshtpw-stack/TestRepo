from .router import router

def register(app):
    app.include_router(router, prefix="/api/v1/alarm-config", tags=["Alarm Config Module"])
