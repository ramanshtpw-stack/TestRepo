import csv
import os
import json
import time
import psutil
import subprocess
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import text, delete

from app.core.database import get_db, SessionLocal
from app.models.alarm import AlarmParameterMaster
from app.models.app_config import AppConfiguration

# Use relative path to find scripts within the module
MODULE_DIR = Path(__file__).resolve().parent
SCRIPTS_DIR = MODULE_DIR / "scripts"

router = APIRouter(tags=["Alarm Config Module"])

# ================== MODELS ==================

class AlarmParameterRow(BaseModel):
    parameter: str
    value: str
    alarm_class: str
    observation_type: str

class SaveAlarmGroupRequest(BaseModel):
    filename: str
    rows: List[AlarmParameterRow]

class RunExportRequest(BaseModel):
    project_path: str
    output_dir: str | None = None
    profile: str | None = None

# ================== HELPER FUNCTIONS ==================

def resolve_config_path(project_path: Path) -> Path:
    """
    Always place config.json one level ABOVE the project root.
    """
    if project_path.parent.name.upper() == "LOGIC":
        return project_path.parent.parent.parent / "config.json"
    return project_path.parent.parent / "config.json"

def load_config(cfg_path: Path) -> dict:
    if cfg_path.exists():
        try:
            return json.loads(cfg_path.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_config(cfg_path: Path, cfg: dict):
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(json.dumps(cfg, indent=4), encoding="utf-8")

def is_codesys_running():
    for proc in psutil.process_iter(["name"]):
        try:
            name = proc.info["name"]
            if name and name.lower() == "codesys.exe":
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return False

# ================== CRUD ENDPOINTS ==================

@router.get("/groups")
def get_alarm_groups(db: Session = Depends(get_db)):
    result = db.execute(text("SELECT DISTINCT filename FROM alarm_parameters ORDER BY filename"))
    return [row[0] for row in result.fetchall()]

@router.get("/parameters")
def get_alarm_parameters(filename: str, db: Session = Depends(get_db)):
    result = db.query(AlarmParameterMaster).filter(
        AlarmParameterMaster.filename == filename
    ).order_by(AlarmParameterMaster.parameter).all()
    
    return [
        {
            "parameter": r.parameter,
            "value": r.value,
            "alarm_class": r.alarm_class,
            "observation_type": r.observation_type
        }
        for r in result
    ]

@router.post("/save-group")
def save_alarm_group(req: SaveAlarmGroupRequest, db: Session = Depends(get_db)):
    try:
        db.query(AlarmParameterMaster).filter(AlarmParameterMaster.filename == req.filename).delete()
        
        new_rows = []
        for r in req.rows:
            if not r.parameter.strip(): continue
            new_rows.append(AlarmParameterMaster(
                filename=req.filename,
                parameter=r.parameter,
                value=r.value,
                alarm_class=r.alarm_class,
                observation_type=r.observation_type
            ))
            
        if new_rows: db.add_all(new_rows)
        db.commit()
        return {"status": "success", "message": "Alarm group saved"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/groups/{filename}")
def delete_alarm_group(filename: str, db: Session = Depends(get_db)):
    try:
        result = db.query(AlarmParameterMaster).filter(AlarmParameterMaster.filename == filename).first()
        if not result: raise HTTPException(status_code=404, detail="Group not found")
        db.query(AlarmParameterMaster).filter(AlarmParameterMaster.filename == filename).delete()
        db.commit()
        return {"status": "success", "message": f"Group '{filename}' deleted"}
    except HTTPException: raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/import-csv")
def import_alarm_csvs(db: Session = Depends(get_db)):
    """Import CSVs from the module's scripts directory."""
    try:
        if not SCRIPTS_DIR.exists():
            raise HTTPException(500, "Scripts directory not found")

        db.query(AlarmParameterMaster).delete()
        imported_count = 0
        csv_files = [f for f in os.listdir(SCRIPTS_DIR) if f.endswith(".csv")]
        
        for file in csv_files:
            file_path = SCRIPTS_DIR / file
            filename = os.path.splitext(file)[0]
            if os.path.getsize(file_path) < 10: continue

            with open(file_path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                rows_to_add = []
                for row in reader:
                    param = row.get("Parameter", "").strip()
                    if not param: continue
                    rows_to_add.append(AlarmParameterMaster(
                        filename=filename,
                        parameter=param,
                        value=row.get("Value", ""),
                        alarm_class=row.get("Class", ""),
                        observation_type=row.get("observation_type", "")
                    ))
                
                if rows_to_add:
                    db.add_all(rows_to_add)
                    imported_count += len(rows_to_add)

        db.commit()
        return {"status": "success", "imported_records": imported_count}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ================== EXECUTION ENDPOINTS ==================

@router.get("/export-status")
def get_export_status():
    """Reads alarm export status from common config.json"""
    config_path = Path(r"C:\Users\Public\Documents\Saksham_Projects\config.json")
    if not config_path.exists(): return {"ready": False}
    try:
        cfg = json.loads(config_path.read_text(encoding="utf-8"))
        return {
            "ready": bool(cfg.get("alarmExportReady")),
            "csvPath": cfg.get("alarmCsvPath")
        }
    except Exception:
        return {"ready": False}

@router.post("/run-export")
def run_export(req: RunExportRequest, db: Session = Depends(get_db)):
    """Executes Alarm_Export.py via Codesys"""
    
    script_name = "Alarm_Export.py"
    script_path = SCRIPTS_DIR / script_name
    
    if not script_path.exists():
        raise HTTPException(400, f"Script not found: {script_path}")

    proj = Path(req.project_path).resolve()
    if not proj.exists():
        raise HTTPException(400, f"Project file not found: {proj}")

    config_path = resolve_config_path(proj)
    output_dir = Path(req.output_dir) if req.output_dir else Path(proj.parent)
    output_dir.mkdir(parents=True, exist_ok=True)

    flag_file = output_dir / "export_done.flag"
    count_file = output_dir / "alarm_count.json"
    
    if flag_file.exists(): flag_file.unlink()
    if count_file.exists(): count_file.unlink()

    # Reset Config State
    cfg = load_config(config_path)
    cfg["alarmExportReady"] = False
    cfg["alarmCsvPath"] = None
    save_config(config_path, cfg)

    # Regenerate JSON for the script to use
    print("[ALARM] Regenerating alarm_config.json from Database...")
    try:
        alarms = db.query(AlarmParameterMaster).all()
        data_map = {}
        for a in alarms:
            if a.filename not in data_map: data_map[a.filename] = []
            data_map[a.filename].append({
                "Parameter": a.parameter,
                "Value": a.value,
                "Class": a.alarm_class,
                "observation_type": a.observation_type
            })
        
        json_path = SCRIPTS_DIR / "alarm_config.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(data_map, f, indent=4)
    except Exception as e:
        print(f"[ALARM] Warning: Failed to regenerate JSON: {e}")

    # Prepare Env
    env = os.environ.copy()
    env["PROJECT_PATH"] = str(proj)
    env["OUTPUT_DIR"] = str(output_dir)
    
    app_config = db.query(AppConfiguration).first()
    if app_config:
        env["CODESYS_USERNAME"] = app_config.codesys_username or ""
        env["CODESYS_PASSWORD"] = app_config.codesys_password or ""
    else:
        env["CODESYS_USERNAME"] = ""
        env["CODESYS_PASSWORD"] = ""

    # Determine Codesys Path
    codesys_exe_path = r"C:\Program Files\CODESYS 3.5.20.60\CODESYS\Common\CODESYS.exe"
    clean_profile = req.profile.strip() if req.profile else ""
    
    if not clean_profile:
        if app_config and app_config.codesys_target_version:
            clean_profile = app_config.codesys_target_version.strip()
            
    if clean_profile == "CODESYS V3.5 SP20":
        codesys_exe_path = r"C:\Program Files\CODESYS 3.5.20.0\CODESYS\Common\CODESYS.exe"

    # Build Command
    cmd_parts = [
        f'"{codesys_exe_path}"',
        f'"{str(proj)}"',
        f'--runscript="{script_path}"'
    ]
    if clean_profile:
        cmd_parts.append(f'--profile="{clean_profile}"')

    cmd = " ".join(cmd_parts)
    print("Executing:", cmd)

    try:
        process = subprocess.Popen(
            cmd, shell=True, env=env,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=0x08000000
        )
    except Exception as e:
        raise HTTPException(500, f"CODESYS execution failed: {str(e)}")

    # Wait for completion
    timeout = 500
    start = time.time()
    while True:
        if flag_file.exists(): break
        if time.time() - start > timeout:
            return {"status": "timeout", "message": "Alarm export took too long"}
        time.sleep(1)

    # Read Count
    alarm_count = None
    if count_file.exists():
        try:
            data = json.loads(count_file.read_text())
            alarm_count = data.get("count")
        except Exception: pass

    # Update Config Success
    csv_path = output_dir / (proj.stem + "_alarms.csv")
    cfg = load_config(config_path)
    cfg["alarmExportReady"] = True
    cfg["alarmCsvPath"] = str(csv_path)
    save_config(config_path, cfg)

    return {
        "status": "completed",
        "message": "Alarm export completed successfully!",
        "csv_file": str(csv_path),
        "alarm_count": alarm_count
    }
